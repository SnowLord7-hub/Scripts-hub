# THIS REPO IS ARCHIVED
:warning: This repo is archived, It no longer works. [Use this instead](https://p3dhack.ru/index.php?/files/file/4-p3dunlocker/)
# Payday 2 DLC Unlocker
A twist on the normal Payday 2 DLC Unlocker.

## Why I made this?
I know that there are so many DLC Unlockers out there for Payday 2 but as far as I could tell none of them allowed to user to enable and disable the DLCs as they wished.

# Usage
## Normal
- Download Payday 2 Super BLT at https://superblt.znix.xyz/
- Put the DLCUnlocker folder in the ``PAYDAY 2/mods`` folder
- Edit the ``PAYDAY 2/mods/DLCUnlocker/UnlockDLCs.lua`` as you wish, just set the DLC you want to ``true`` instead of ``false``
## Hidden(Renames the mod to 'Crash Fixer')
- Download Payday 2 Super BLT at https://superblt.znix.xyz/
- Put the DLCUnlocker_Hidden folder in the ``PAYDAY 2/mods`` folder
- Edit the ``PAYDAY 2/mods/DLCUnlocker_Hidden/UnlockDLCs.lua`` as you wish, just set the DLC you want to ``true`` instead of ``false``

## License
[MIT](https://choosealicense.com/licenses/mit/)
