---
name: Bypass Request
about: A website isn't bypassed
title: 'ENTER DOMAIN HERE'
labels: 'new bypass'

---

Before you report a website that isn't bypassed yet, please use the search function to ensure that the site wasn't already reported: https://github.com/Sainan/Universal-Bypass/issues?utf8=%E2%9C%93&q=ENTER+DOMAIN+HERE

If that is not the case, please **provide an example link.** We need to be able to see what there is to be bypassed, otherwise there can't be a bypass.
