# Universal Bypass

Don't waste your time with compliance. Universal Bypass automatically skips annoying link shorteners.

- [Homepage](https://universal-bypass.org)
- [Install Universal Bypass](https://universal-bypass.org/install)
- [Frequently Asked Questions (FAQ)](https://universal-bypass.org/faq)
- [Support Universal Bypass](https://universal-bypass.org/support)
  - [Translate Universal Bypass on Crowdin](https://crowdin.com/project/bypass)
- [Changelog](https://universal-bypass.org/changelog)
