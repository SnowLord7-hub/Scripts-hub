# Security Policy

## Supported Versions

| Version   | Supported          |
| -------   | ------------------ |
| 6.9.(nks) | :x:                |
| 0.0.4     | :zzz:              |
| 0.1.0     | :white_check_mark: |
| other     | :x:                |

## Reporting a Vulnerability

[Join](https://cheatpack.glitch.me/discord) our Discord server and report a Vulnerability through DM'ing Owner (Naveq#0444).
